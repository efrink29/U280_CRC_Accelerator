
    wire dl_reset;
    wire dl_clock;
    assign dl_reset = ap_rst_n;
    assign dl_clock = ap_clk;
    wire [3:0] proc_0_data_FIFO_blk;
    wire [3:0] proc_0_data_PIPO_blk;
    wire [3:0] proc_0_start_FIFO_blk;
    wire [3:0] proc_0_TLF_FIFO_blk;
    wire [3:0] proc_0_input_sync_blk;
    wire [3:0] proc_0_output_sync_blk;
    wire [3:0] proc_dep_vld_vec_0;
    reg [3:0] proc_dep_vld_vec_0_reg;
    wire [3:0] in_chan_dep_vld_vec_0;
    wire [19:0] in_chan_dep_data_vec_0;
    wire [3:0] token_in_vec_0;
    wire [3:0] out_chan_dep_vld_vec_0;
    wire [4:0] out_chan_dep_data_0;
    wire [3:0] token_out_vec_0;
    wire dl_detect_out_0;
    wire dep_chan_vld_1_0;
    wire [4:0] dep_chan_data_1_0;
    wire token_1_0;
    wire dep_chan_vld_2_0;
    wire [4:0] dep_chan_data_2_0;
    wire token_2_0;
    wire dep_chan_vld_3_0;
    wire [4:0] dep_chan_data_3_0;
    wire token_3_0;
    wire dep_chan_vld_4_0;
    wire [4:0] dep_chan_data_4_0;
    wire token_4_0;
    wire [2:0] proc_1_data_FIFO_blk;
    wire [2:0] proc_1_data_PIPO_blk;
    wire [2:0] proc_1_start_FIFO_blk;
    wire [2:0] proc_1_TLF_FIFO_blk;
    wire [2:0] proc_1_input_sync_blk;
    wire [2:0] proc_1_output_sync_blk;
    wire [2:0] proc_dep_vld_vec_1;
    reg [2:0] proc_dep_vld_vec_1_reg;
    wire [2:0] in_chan_dep_vld_vec_1;
    wire [14:0] in_chan_dep_data_vec_1;
    wire [2:0] token_in_vec_1;
    wire [2:0] out_chan_dep_vld_vec_1;
    wire [4:0] out_chan_dep_data_1;
    wire [2:0] token_out_vec_1;
    wire dl_detect_out_1;
    wire dep_chan_vld_0_1;
    wire [4:0] dep_chan_data_0_1;
    wire token_0_1;
    wire dep_chan_vld_2_1;
    wire [4:0] dep_chan_data_2_1;
    wire token_2_1;
    wire dep_chan_vld_3_1;
    wire [4:0] dep_chan_data_3_1;
    wire token_3_1;
    wire [2:0] proc_2_data_FIFO_blk;
    wire [2:0] proc_2_data_PIPO_blk;
    wire [2:0] proc_2_start_FIFO_blk;
    wire [2:0] proc_2_TLF_FIFO_blk;
    wire [2:0] proc_2_input_sync_blk;
    wire [2:0] proc_2_output_sync_blk;
    wire [2:0] proc_dep_vld_vec_2;
    reg [2:0] proc_dep_vld_vec_2_reg;
    wire [2:0] in_chan_dep_vld_vec_2;
    wire [14:0] in_chan_dep_data_vec_2;
    wire [2:0] token_in_vec_2;
    wire [2:0] out_chan_dep_vld_vec_2;
    wire [4:0] out_chan_dep_data_2;
    wire [2:0] token_out_vec_2;
    wire dl_detect_out_2;
    wire dep_chan_vld_0_2;
    wire [4:0] dep_chan_data_0_2;
    wire token_0_2;
    wire dep_chan_vld_1_2;
    wire [4:0] dep_chan_data_1_2;
    wire token_1_2;
    wire dep_chan_vld_3_2;
    wire [4:0] dep_chan_data_3_2;
    wire token_3_2;
    wire [3:0] proc_3_data_FIFO_blk;
    wire [3:0] proc_3_data_PIPO_blk;
    wire [3:0] proc_3_start_FIFO_blk;
    wire [3:0] proc_3_TLF_FIFO_blk;
    wire [3:0] proc_3_input_sync_blk;
    wire [3:0] proc_3_output_sync_blk;
    wire [3:0] proc_dep_vld_vec_3;
    reg [3:0] proc_dep_vld_vec_3_reg;
    wire [3:0] in_chan_dep_vld_vec_3;
    wire [19:0] in_chan_dep_data_vec_3;
    wire [3:0] token_in_vec_3;
    wire [3:0] out_chan_dep_vld_vec_3;
    wire [4:0] out_chan_dep_data_3;
    wire [3:0] token_out_vec_3;
    wire dl_detect_out_3;
    wire dep_chan_vld_0_3;
    wire [4:0] dep_chan_data_0_3;
    wire token_0_3;
    wire dep_chan_vld_1_3;
    wire [4:0] dep_chan_data_1_3;
    wire token_1_3;
    wire dep_chan_vld_2_3;
    wire [4:0] dep_chan_data_2_3;
    wire token_2_3;
    wire dep_chan_vld_4_3;
    wire [4:0] dep_chan_data_4_3;
    wire token_4_3;
    wire [1:0] proc_4_data_FIFO_blk;
    wire [1:0] proc_4_data_PIPO_blk;
    wire [1:0] proc_4_start_FIFO_blk;
    wire [1:0] proc_4_TLF_FIFO_blk;
    wire [1:0] proc_4_input_sync_blk;
    wire [1:0] proc_4_output_sync_blk;
    wire [1:0] proc_dep_vld_vec_4;
    reg [1:0] proc_dep_vld_vec_4_reg;
    wire [1:0] in_chan_dep_vld_vec_4;
    wire [9:0] in_chan_dep_data_vec_4;
    wire [1:0] token_in_vec_4;
    wire [1:0] out_chan_dep_vld_vec_4;
    wire [4:0] out_chan_dep_data_4;
    wire [1:0] token_out_vec_4;
    wire dl_detect_out_4;
    wire dep_chan_vld_0_4;
    wire [4:0] dep_chan_data_0_4;
    wire token_0_4;
    wire dep_chan_vld_3_4;
    wire [4:0] dep_chan_data_3_4;
    wire token_3_4;
    wire [4:0] dl_in_vec;
    wire dl_detect_out;
    wire token_clear;
    reg [4:0] origin;

    reg ap_done_reg_0;// for module grp_process_crc_fu_122.process_crc_Loop_init_lut_proc_U0
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            ap_done_reg_0 <= 'b0;
        end
        else begin
            ap_done_reg_0 <= grp_process_crc_fu_122.process_crc_Loop_init_lut_proc_U0.ap_done & ~grp_process_crc_fu_122.process_crc_Loop_init_lut_proc_U0.ap_continue;
        end
    end

    reg ap_done_reg_1;// for module grp_process_crc_fu_122.process_blocks_U0
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            ap_done_reg_1 <= 'b0;
        end
        else begin
            ap_done_reg_1 <= grp_process_crc_fu_122.process_blocks_U0.ap_done & ~grp_process_crc_fu_122.process_blocks_U0.ap_continue;
        end
    end

reg [15:0] trans_in_cnt_0;// for process grp_process_crc_fu_122.entry_proc_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_in_cnt_0 <= 16'h0;
    end
    else if (grp_process_crc_fu_122.entry_proc_U0.start_write == 1'b1) begin
        trans_in_cnt_0 <= trans_in_cnt_0 + 16'h1;
    end
    else begin
        trans_in_cnt_0 <= trans_in_cnt_0;
    end
end

reg [15:0] trans_out_cnt_0;// for process grp_process_crc_fu_122.entry_proc_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_out_cnt_0 <= 16'h0;
    end
    else if (grp_process_crc_fu_122.entry_proc_U0.ap_done == 1'b1 && grp_process_crc_fu_122.entry_proc_U0.ap_continue == 1'b1) begin
        trans_out_cnt_0 <= trans_out_cnt_0 + 16'h1;
    end
    else begin
        trans_out_cnt_0 <= trans_out_cnt_0;
    end
end

    // Process: grp_process_crc_fu_122.entry_proc_U0
    calculate_crc_hls_deadlock_detect_unit #(5, 0, 4, 4) calculate_crc_hls_deadlock_detect_unit_0 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_0),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_0),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_0),
        .token_in_vec(token_in_vec_0),
        .dl_detect_in(dl_detect_out),
        .origin(origin[0]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_0),
        .out_chan_dep_data(out_chan_dep_data_0),
        .token_out_vec(token_out_vec_0),
        .dl_detect_out(dl_in_vec[0]));

    assign proc_0_data_FIFO_blk[0] = 1'b0 | (~grp_process_crc_fu_122.entry_proc_U0.crc_out_c_blk_n);
    assign proc_0_data_PIPO_blk[0] = 1'b0;
    assign proc_0_start_FIFO_blk[0] = 1'b0 | (~grp_process_crc_fu_122.start_for_write_output_U0_U.if_full_n & grp_process_crc_fu_122.entry_proc_U0.ap_start & ~grp_process_crc_fu_122.entry_proc_U0.real_start & (trans_in_cnt_0 == trans_out_cnt_0) & ~grp_process_crc_fu_122.start_for_write_output_U0_U.if_read);
    assign proc_0_TLF_FIFO_blk[0] = 1'b0;
    assign proc_0_input_sync_blk[0] = 1'b0;
    assign proc_0_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_0[0] = dl_detect_out ? proc_dep_vld_vec_0_reg[0] : (proc_0_data_FIFO_blk[0] | proc_0_data_PIPO_blk[0] | proc_0_start_FIFO_blk[0] | proc_0_TLF_FIFO_blk[0] | proc_0_input_sync_blk[0] | proc_0_output_sync_blk[0]);
    assign proc_0_data_FIFO_blk[1] = 1'b0 | (~grp_process_crc_fu_122.entry_proc_U0.crc_size_c_blk_n) | (~grp_process_crc_fu_122.entry_proc_U0.init_value_c_blk_n);
    assign proc_0_data_PIPO_blk[1] = 1'b0;
    assign proc_0_start_FIFO_blk[1] = 1'b0;
    assign proc_0_TLF_FIFO_blk[1] = 1'b0;
    assign proc_0_input_sync_blk[1] = 1'b0;
    assign proc_0_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_0[1] = dl_detect_out ? proc_dep_vld_vec_0_reg[1] : (proc_0_data_FIFO_blk[1] | proc_0_data_PIPO_blk[1] | proc_0_start_FIFO_blk[1] | proc_0_TLF_FIFO_blk[1] | proc_0_input_sync_blk[1] | proc_0_output_sync_blk[1]);
    assign proc_0_data_FIFO_blk[2] = 1'b0;
    assign proc_0_data_PIPO_blk[2] = 1'b0;
    assign proc_0_start_FIFO_blk[2] = 1'b0;
    assign proc_0_TLF_FIFO_blk[2] = 1'b0;
    assign proc_0_input_sync_blk[2] = 1'b0 | (grp_process_crc_fu_122.ap_sync_entry_proc_U0_ap_ready & grp_process_crc_fu_122.entry_proc_U0.ap_idle & ~grp_process_crc_fu_122.ap_sync_process_crc_Loop_init_lut_proc_U0_ap_ready);
    assign proc_0_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_0[2] = dl_detect_out ? proc_dep_vld_vec_0_reg[2] : (proc_0_data_FIFO_blk[2] | proc_0_data_PIPO_blk[2] | proc_0_start_FIFO_blk[2] | proc_0_TLF_FIFO_blk[2] | proc_0_input_sync_blk[2] | proc_0_output_sync_blk[2]);
    assign proc_0_data_FIFO_blk[3] = 1'b0;
    assign proc_0_data_PIPO_blk[3] = 1'b0;
    assign proc_0_start_FIFO_blk[3] = 1'b0;
    assign proc_0_TLF_FIFO_blk[3] = 1'b0;
    assign proc_0_input_sync_blk[3] = 1'b0 | (grp_process_crc_fu_122.ap_sync_entry_proc_U0_ap_ready & grp_process_crc_fu_122.entry_proc_U0.ap_idle & ~grp_process_crc_fu_122.ap_sync_read_input_U0_ap_ready);
    assign proc_0_output_sync_blk[3] = 1'b0;
    assign proc_dep_vld_vec_0[3] = dl_detect_out ? proc_dep_vld_vec_0_reg[3] : (proc_0_data_FIFO_blk[3] | proc_0_data_PIPO_blk[3] | proc_0_start_FIFO_blk[3] | proc_0_TLF_FIFO_blk[3] | proc_0_input_sync_blk[3] | proc_0_output_sync_blk[3]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_0_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_0_reg <= proc_dep_vld_vec_0;
        end
    end
    assign in_chan_dep_vld_vec_0[0] = dep_chan_vld_1_0;
    assign in_chan_dep_data_vec_0[4 : 0] = dep_chan_data_1_0;
    assign token_in_vec_0[0] = token_1_0;
    assign in_chan_dep_vld_vec_0[1] = dep_chan_vld_2_0;
    assign in_chan_dep_data_vec_0[9 : 5] = dep_chan_data_2_0;
    assign token_in_vec_0[1] = token_2_0;
    assign in_chan_dep_vld_vec_0[2] = dep_chan_vld_3_0;
    assign in_chan_dep_data_vec_0[14 : 10] = dep_chan_data_3_0;
    assign token_in_vec_0[2] = token_3_0;
    assign in_chan_dep_vld_vec_0[3] = dep_chan_vld_4_0;
    assign in_chan_dep_data_vec_0[19 : 15] = dep_chan_data_4_0;
    assign token_in_vec_0[3] = token_4_0;
    assign dep_chan_vld_0_4 = out_chan_dep_vld_vec_0[0];
    assign dep_chan_data_0_4 = out_chan_dep_data_0;
    assign token_0_4 = token_out_vec_0[0];
    assign dep_chan_vld_0_3 = out_chan_dep_vld_vec_0[1];
    assign dep_chan_data_0_3 = out_chan_dep_data_0;
    assign token_0_3 = token_out_vec_0[1];
    assign dep_chan_vld_0_1 = out_chan_dep_vld_vec_0[2];
    assign dep_chan_data_0_1 = out_chan_dep_data_0;
    assign token_0_1 = token_out_vec_0[2];
    assign dep_chan_vld_0_2 = out_chan_dep_vld_vec_0[3];
    assign dep_chan_data_0_2 = out_chan_dep_data_0;
    assign token_0_2 = token_out_vec_0[3];

    // Process: grp_process_crc_fu_122.process_crc_Loop_init_lut_proc_U0
    calculate_crc_hls_deadlock_detect_unit #(5, 1, 3, 3) calculate_crc_hls_deadlock_detect_unit_1 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_1),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_1),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_1),
        .token_in_vec(token_in_vec_1),
        .dl_detect_in(dl_detect_out),
        .origin(origin[1]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_1),
        .out_chan_dep_data(out_chan_dep_data_1),
        .token_out_vec(token_out_vec_1),
        .dl_detect_out(dl_in_vec[1]));

    assign proc_1_data_FIFO_blk[0] = 1'b0;
    assign proc_1_data_PIPO_blk[0] = 1'b0 | (~grp_process_crc_fu_122.crcTables_15_U.i_full_n & grp_process_crc_fu_122.process_crc_Loop_init_lut_proc_U0.ap_done & ap_done_reg_0 & ~grp_process_crc_fu_122.crcTables_15_U.t_read) | (~grp_process_crc_fu_122.crcTables_14_U.i_full_n & grp_process_crc_fu_122.process_crc_Loop_init_lut_proc_U0.ap_done & ap_done_reg_0 & ~grp_process_crc_fu_122.crcTables_14_U.t_read) | (~grp_process_crc_fu_122.crcTables_13_U.i_full_n & grp_process_crc_fu_122.process_crc_Loop_init_lut_proc_U0.ap_done & ap_done_reg_0 & ~grp_process_crc_fu_122.crcTables_13_U.t_read) | (~grp_process_crc_fu_122.crcTables_12_U.i_full_n & grp_process_crc_fu_122.process_crc_Loop_init_lut_proc_U0.ap_done & ap_done_reg_0 & ~grp_process_crc_fu_122.crcTables_12_U.t_read) | (~grp_process_crc_fu_122.crcTables_11_U.i_full_n & grp_process_crc_fu_122.process_crc_Loop_init_lut_proc_U0.ap_done & ap_done_reg_0 & ~grp_process_crc_fu_122.crcTables_11_U.t_read) | (~grp_process_crc_fu_122.crcTables_10_U.i_full_n & grp_process_crc_fu_122.process_crc_Loop_init_lut_proc_U0.ap_done & ap_done_reg_0 & ~grp_process_crc_fu_122.crcTables_10_U.t_read) | (~grp_process_crc_fu_122.crcTables_9_U.i_full_n & grp_process_crc_fu_122.process_crc_Loop_init_lut_proc_U0.ap_done & ap_done_reg_0 & ~grp_process_crc_fu_122.crcTables_9_U.t_read) | (~grp_process_crc_fu_122.crcTables_8_U.i_full_n & grp_process_crc_fu_122.process_crc_Loop_init_lut_proc_U0.ap_done & ap_done_reg_0 & ~grp_process_crc_fu_122.crcTables_8_U.t_read) | (~grp_process_crc_fu_122.crcTables_7_U.i_full_n & grp_process_crc_fu_122.process_crc_Loop_init_lut_proc_U0.ap_done & ap_done_reg_0 & ~grp_process_crc_fu_122.crcTables_7_U.t_read) | (~grp_process_crc_fu_122.crcTables_6_U.i_full_n & grp_process_crc_fu_122.process_crc_Loop_init_lut_proc_U0.ap_done & ap_done_reg_0 & ~grp_process_crc_fu_122.crcTables_6_U.t_read) | (~grp_process_crc_fu_122.crcTables_5_U.i_full_n & grp_process_crc_fu_122.process_crc_Loop_init_lut_proc_U0.ap_done & ap_done_reg_0 & ~grp_process_crc_fu_122.crcTables_5_U.t_read) | (~grp_process_crc_fu_122.crcTables_4_U.i_full_n & grp_process_crc_fu_122.process_crc_Loop_init_lut_proc_U0.ap_done & ap_done_reg_0 & ~grp_process_crc_fu_122.crcTables_4_U.t_read) | (~grp_process_crc_fu_122.crcTables_3_U.i_full_n & grp_process_crc_fu_122.process_crc_Loop_init_lut_proc_U0.ap_done & ap_done_reg_0 & ~grp_process_crc_fu_122.crcTables_3_U.t_read) | (~grp_process_crc_fu_122.crcTables_2_U.i_full_n & grp_process_crc_fu_122.process_crc_Loop_init_lut_proc_U0.ap_done & ap_done_reg_0 & ~grp_process_crc_fu_122.crcTables_2_U.t_read) | (~grp_process_crc_fu_122.crcTables_1_U.i_full_n & grp_process_crc_fu_122.process_crc_Loop_init_lut_proc_U0.ap_done & ap_done_reg_0 & ~grp_process_crc_fu_122.crcTables_1_U.t_read) | (~grp_process_crc_fu_122.crcTables_U.i_full_n & grp_process_crc_fu_122.process_crc_Loop_init_lut_proc_U0.ap_done & ap_done_reg_0 & ~grp_process_crc_fu_122.crcTables_U.t_read);
    assign proc_1_start_FIFO_blk[0] = 1'b0;
    assign proc_1_TLF_FIFO_blk[0] = 1'b0;
    assign proc_1_input_sync_blk[0] = 1'b0;
    assign proc_1_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_1[0] = dl_detect_out ? proc_dep_vld_vec_1_reg[0] : (proc_1_data_FIFO_blk[0] | proc_1_data_PIPO_blk[0] | proc_1_start_FIFO_blk[0] | proc_1_TLF_FIFO_blk[0] | proc_1_input_sync_blk[0] | proc_1_output_sync_blk[0]);
    assign proc_1_data_FIFO_blk[1] = 1'b0;
    assign proc_1_data_PIPO_blk[1] = 1'b0;
    assign proc_1_start_FIFO_blk[1] = 1'b0;
    assign proc_1_TLF_FIFO_blk[1] = 1'b0;
    assign proc_1_input_sync_blk[1] = 1'b0 | (grp_process_crc_fu_122.ap_sync_process_crc_Loop_init_lut_proc_U0_ap_ready & grp_process_crc_fu_122.process_crc_Loop_init_lut_proc_U0.ap_idle & ~grp_process_crc_fu_122.ap_sync_entry_proc_U0_ap_ready);
    assign proc_1_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_1[1] = dl_detect_out ? proc_dep_vld_vec_1_reg[1] : (proc_1_data_FIFO_blk[1] | proc_1_data_PIPO_blk[1] | proc_1_start_FIFO_blk[1] | proc_1_TLF_FIFO_blk[1] | proc_1_input_sync_blk[1] | proc_1_output_sync_blk[1]);
    assign proc_1_data_FIFO_blk[2] = 1'b0;
    assign proc_1_data_PIPO_blk[2] = 1'b0;
    assign proc_1_start_FIFO_blk[2] = 1'b0;
    assign proc_1_TLF_FIFO_blk[2] = 1'b0;
    assign proc_1_input_sync_blk[2] = 1'b0 | (grp_process_crc_fu_122.ap_sync_process_crc_Loop_init_lut_proc_U0_ap_ready & grp_process_crc_fu_122.process_crc_Loop_init_lut_proc_U0.ap_idle & ~grp_process_crc_fu_122.ap_sync_read_input_U0_ap_ready);
    assign proc_1_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_1[2] = dl_detect_out ? proc_dep_vld_vec_1_reg[2] : (proc_1_data_FIFO_blk[2] | proc_1_data_PIPO_blk[2] | proc_1_start_FIFO_blk[2] | proc_1_TLF_FIFO_blk[2] | proc_1_input_sync_blk[2] | proc_1_output_sync_blk[2]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_1_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_1_reg <= proc_dep_vld_vec_1;
        end
    end
    assign in_chan_dep_vld_vec_1[0] = dep_chan_vld_0_1;
    assign in_chan_dep_data_vec_1[4 : 0] = dep_chan_data_0_1;
    assign token_in_vec_1[0] = token_0_1;
    assign in_chan_dep_vld_vec_1[1] = dep_chan_vld_2_1;
    assign in_chan_dep_data_vec_1[9 : 5] = dep_chan_data_2_1;
    assign token_in_vec_1[1] = token_2_1;
    assign in_chan_dep_vld_vec_1[2] = dep_chan_vld_3_1;
    assign in_chan_dep_data_vec_1[14 : 10] = dep_chan_data_3_1;
    assign token_in_vec_1[2] = token_3_1;
    assign dep_chan_vld_1_3 = out_chan_dep_vld_vec_1[0];
    assign dep_chan_data_1_3 = out_chan_dep_data_1;
    assign token_1_3 = token_out_vec_1[0];
    assign dep_chan_vld_1_0 = out_chan_dep_vld_vec_1[1];
    assign dep_chan_data_1_0 = out_chan_dep_data_1;
    assign token_1_0 = token_out_vec_1[1];
    assign dep_chan_vld_1_2 = out_chan_dep_vld_vec_1[2];
    assign dep_chan_data_1_2 = out_chan_dep_data_1;
    assign token_1_2 = token_out_vec_1[2];

    // Process: grp_process_crc_fu_122.read_input_U0
    calculate_crc_hls_deadlock_detect_unit #(5, 2, 3, 3) calculate_crc_hls_deadlock_detect_unit_2 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_2),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_2),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_2),
        .token_in_vec(token_in_vec_2),
        .dl_detect_in(dl_detect_out),
        .origin(origin[2]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_2),
        .out_chan_dep_data(out_chan_dep_data_2),
        .token_out_vec(token_out_vec_2),
        .dl_detect_out(dl_in_vec[2]));

    assign proc_2_data_FIFO_blk[0] = 1'b0 | (~grp_process_crc_fu_122.read_input_U0.grp_read_input_Pipeline_mem_rd_fu_142.inByte0_blk_n) | (~grp_process_crc_fu_122.read_input_U0.grp_read_input_Pipeline_mem_rd_fu_142.inByte1_blk_n) | (~grp_process_crc_fu_122.read_input_U0.grp_read_input_Pipeline_mem_rd_fu_142.inByte2_blk_n) | (~grp_process_crc_fu_122.read_input_U0.grp_read_input_Pipeline_mem_rd_fu_142.inByte3_blk_n) | (~grp_process_crc_fu_122.read_input_U0.grp_read_input_Pipeline_mem_rd_fu_142.inByte4_blk_n) | (~grp_process_crc_fu_122.read_input_U0.grp_read_input_Pipeline_mem_rd_fu_142.inByte5_blk_n) | (~grp_process_crc_fu_122.read_input_U0.grp_read_input_Pipeline_mem_rd_fu_142.inByte6_blk_n) | (~grp_process_crc_fu_122.read_input_U0.grp_read_input_Pipeline_mem_rd_fu_142.inByte7_blk_n) | (~grp_process_crc_fu_122.read_input_U0.grp_read_input_Pipeline_mem_rd_fu_142.inByte8_blk_n) | (~grp_process_crc_fu_122.read_input_U0.grp_read_input_Pipeline_mem_rd_fu_142.inByte9_blk_n) | (~grp_process_crc_fu_122.read_input_U0.grp_read_input_Pipeline_mem_rd_fu_142.inByte10_blk_n) | (~grp_process_crc_fu_122.read_input_U0.grp_read_input_Pipeline_mem_rd_fu_142.inByte11_blk_n) | (~grp_process_crc_fu_122.read_input_U0.grp_read_input_Pipeline_mem_rd_fu_142.inByte12_blk_n) | (~grp_process_crc_fu_122.read_input_U0.grp_read_input_Pipeline_mem_rd_fu_142.inByte13_blk_n) | (~grp_process_crc_fu_122.read_input_U0.grp_read_input_Pipeline_mem_rd_fu_142.inByte14_blk_n) | (~grp_process_crc_fu_122.read_input_U0.grp_read_input_Pipeline_mem_rd_fu_142.inByte15_blk_n) | (~grp_process_crc_fu_122.read_input_U0.numChunks_c12_blk_n) | (~grp_process_crc_fu_122.read_input_U0.chunkSize_c_blk_n);
    assign proc_2_data_PIPO_blk[0] = 1'b0;
    assign proc_2_start_FIFO_blk[0] = 1'b0;
    assign proc_2_TLF_FIFO_blk[0] = 1'b0;
    assign proc_2_input_sync_blk[0] = 1'b0;
    assign proc_2_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_2[0] = dl_detect_out ? proc_dep_vld_vec_2_reg[0] : (proc_2_data_FIFO_blk[0] | proc_2_data_PIPO_blk[0] | proc_2_start_FIFO_blk[0] | proc_2_TLF_FIFO_blk[0] | proc_2_input_sync_blk[0] | proc_2_output_sync_blk[0]);
    assign proc_2_data_FIFO_blk[1] = 1'b0;
    assign proc_2_data_PIPO_blk[1] = 1'b0;
    assign proc_2_start_FIFO_blk[1] = 1'b0;
    assign proc_2_TLF_FIFO_blk[1] = 1'b0;
    assign proc_2_input_sync_blk[1] = 1'b0 | (grp_process_crc_fu_122.ap_sync_read_input_U0_ap_ready & grp_process_crc_fu_122.read_input_U0.ap_idle & ~grp_process_crc_fu_122.ap_sync_entry_proc_U0_ap_ready);
    assign proc_2_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_2[1] = dl_detect_out ? proc_dep_vld_vec_2_reg[1] : (proc_2_data_FIFO_blk[1] | proc_2_data_PIPO_blk[1] | proc_2_start_FIFO_blk[1] | proc_2_TLF_FIFO_blk[1] | proc_2_input_sync_blk[1] | proc_2_output_sync_blk[1]);
    assign proc_2_data_FIFO_blk[2] = 1'b0;
    assign proc_2_data_PIPO_blk[2] = 1'b0;
    assign proc_2_start_FIFO_blk[2] = 1'b0;
    assign proc_2_TLF_FIFO_blk[2] = 1'b0;
    assign proc_2_input_sync_blk[2] = 1'b0 | (grp_process_crc_fu_122.ap_sync_read_input_U0_ap_ready & grp_process_crc_fu_122.read_input_U0.ap_idle & ~grp_process_crc_fu_122.ap_sync_process_crc_Loop_init_lut_proc_U0_ap_ready);
    assign proc_2_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_2[2] = dl_detect_out ? proc_dep_vld_vec_2_reg[2] : (proc_2_data_FIFO_blk[2] | proc_2_data_PIPO_blk[2] | proc_2_start_FIFO_blk[2] | proc_2_TLF_FIFO_blk[2] | proc_2_input_sync_blk[2] | proc_2_output_sync_blk[2]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_2_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_2_reg <= proc_dep_vld_vec_2;
        end
    end
    assign in_chan_dep_vld_vec_2[0] = dep_chan_vld_0_2;
    assign in_chan_dep_data_vec_2[4 : 0] = dep_chan_data_0_2;
    assign token_in_vec_2[0] = token_0_2;
    assign in_chan_dep_vld_vec_2[1] = dep_chan_vld_1_2;
    assign in_chan_dep_data_vec_2[9 : 5] = dep_chan_data_1_2;
    assign token_in_vec_2[1] = token_1_2;
    assign in_chan_dep_vld_vec_2[2] = dep_chan_vld_3_2;
    assign in_chan_dep_data_vec_2[14 : 10] = dep_chan_data_3_2;
    assign token_in_vec_2[2] = token_3_2;
    assign dep_chan_vld_2_3 = out_chan_dep_vld_vec_2[0];
    assign dep_chan_data_2_3 = out_chan_dep_data_2;
    assign token_2_3 = token_out_vec_2[0];
    assign dep_chan_vld_2_0 = out_chan_dep_vld_vec_2[1];
    assign dep_chan_data_2_0 = out_chan_dep_data_2;
    assign token_2_0 = token_out_vec_2[1];
    assign dep_chan_vld_2_1 = out_chan_dep_vld_vec_2[2];
    assign dep_chan_data_2_1 = out_chan_dep_data_2;
    assign token_2_1 = token_out_vec_2[2];

    // Process: grp_process_crc_fu_122.process_blocks_U0
    calculate_crc_hls_deadlock_detect_unit #(5, 3, 4, 4) calculate_crc_hls_deadlock_detect_unit_3 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_3),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_3),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_3),
        .token_in_vec(token_in_vec_3),
        .dl_detect_in(dl_detect_out),
        .origin(origin[3]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_3),
        .out_chan_dep_data(out_chan_dep_data_3),
        .token_out_vec(token_out_vec_3),
        .dl_detect_out(dl_in_vec[3]));

    assign proc_3_data_FIFO_blk[0] = 1'b0;
    assign proc_3_data_PIPO_blk[0] = 1'b0 | (~grp_process_crc_fu_122.crcTables_U.t_empty_n & grp_process_crc_fu_122.process_blocks_U0.ap_idle & ~grp_process_crc_fu_122.crcTables_U.i_write) | (~grp_process_crc_fu_122.crcTables_1_U.t_empty_n & grp_process_crc_fu_122.process_blocks_U0.ap_idle & ~grp_process_crc_fu_122.crcTables_1_U.i_write) | (~grp_process_crc_fu_122.crcTables_2_U.t_empty_n & grp_process_crc_fu_122.process_blocks_U0.ap_idle & ~grp_process_crc_fu_122.crcTables_2_U.i_write) | (~grp_process_crc_fu_122.crcTables_3_U.t_empty_n & grp_process_crc_fu_122.process_blocks_U0.ap_idle & ~grp_process_crc_fu_122.crcTables_3_U.i_write) | (~grp_process_crc_fu_122.crcTables_4_U.t_empty_n & grp_process_crc_fu_122.process_blocks_U0.ap_idle & ~grp_process_crc_fu_122.crcTables_4_U.i_write) | (~grp_process_crc_fu_122.crcTables_5_U.t_empty_n & grp_process_crc_fu_122.process_blocks_U0.ap_idle & ~grp_process_crc_fu_122.crcTables_5_U.i_write) | (~grp_process_crc_fu_122.crcTables_6_U.t_empty_n & grp_process_crc_fu_122.process_blocks_U0.ap_idle & ~grp_process_crc_fu_122.crcTables_6_U.i_write) | (~grp_process_crc_fu_122.crcTables_7_U.t_empty_n & grp_process_crc_fu_122.process_blocks_U0.ap_idle & ~grp_process_crc_fu_122.crcTables_7_U.i_write) | (~grp_process_crc_fu_122.crcTables_8_U.t_empty_n & grp_process_crc_fu_122.process_blocks_U0.ap_idle & ~grp_process_crc_fu_122.crcTables_8_U.i_write) | (~grp_process_crc_fu_122.crcTables_9_U.t_empty_n & grp_process_crc_fu_122.process_blocks_U0.ap_idle & ~grp_process_crc_fu_122.crcTables_9_U.i_write) | (~grp_process_crc_fu_122.crcTables_10_U.t_empty_n & grp_process_crc_fu_122.process_blocks_U0.ap_idle & ~grp_process_crc_fu_122.crcTables_10_U.i_write) | (~grp_process_crc_fu_122.crcTables_11_U.t_empty_n & grp_process_crc_fu_122.process_blocks_U0.ap_idle & ~grp_process_crc_fu_122.crcTables_11_U.i_write) | (~grp_process_crc_fu_122.crcTables_12_U.t_empty_n & grp_process_crc_fu_122.process_blocks_U0.ap_idle & ~grp_process_crc_fu_122.crcTables_12_U.i_write) | (~grp_process_crc_fu_122.crcTables_13_U.t_empty_n & grp_process_crc_fu_122.process_blocks_U0.ap_idle & ~grp_process_crc_fu_122.crcTables_13_U.i_write) | (~grp_process_crc_fu_122.crcTables_14_U.t_empty_n & grp_process_crc_fu_122.process_blocks_U0.ap_idle & ~grp_process_crc_fu_122.crcTables_14_U.i_write) | (~grp_process_crc_fu_122.crcTables_15_U.t_empty_n & grp_process_crc_fu_122.process_blocks_U0.ap_idle & ~grp_process_crc_fu_122.crcTables_15_U.i_write);
    assign proc_3_start_FIFO_blk[0] = 1'b0;
    assign proc_3_TLF_FIFO_blk[0] = 1'b0;
    assign proc_3_input_sync_blk[0] = 1'b0;
    assign proc_3_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_3[0] = dl_detect_out ? proc_dep_vld_vec_3_reg[0] : (proc_3_data_FIFO_blk[0] | proc_3_data_PIPO_blk[0] | proc_3_start_FIFO_blk[0] | proc_3_TLF_FIFO_blk[0] | proc_3_input_sync_blk[0] | proc_3_output_sync_blk[0]);
    assign proc_3_data_FIFO_blk[1] = 1'b0 | (~grp_process_crc_fu_122.process_blocks_U0.grp_process_blocks_Pipeline_block_loop_fu_199.inByte0_blk_n) | (~grp_process_crc_fu_122.process_blocks_U0.grp_process_blocks_Pipeline_block_loop_fu_199.inByte1_blk_n) | (~grp_process_crc_fu_122.process_blocks_U0.grp_process_blocks_Pipeline_block_loop_fu_199.inByte2_blk_n) | (~grp_process_crc_fu_122.process_blocks_U0.grp_process_blocks_Pipeline_block_loop_fu_199.inByte3_blk_n) | (~grp_process_crc_fu_122.process_blocks_U0.grp_process_blocks_Pipeline_block_loop_fu_199.inByte4_blk_n) | (~grp_process_crc_fu_122.process_blocks_U0.grp_process_blocks_Pipeline_block_loop_fu_199.inByte5_blk_n) | (~grp_process_crc_fu_122.process_blocks_U0.grp_process_blocks_Pipeline_block_loop_fu_199.inByte6_blk_n) | (~grp_process_crc_fu_122.process_blocks_U0.grp_process_blocks_Pipeline_block_loop_fu_199.inByte7_blk_n) | (~grp_process_crc_fu_122.process_blocks_U0.grp_process_blocks_Pipeline_block_loop_fu_199.inByte8_blk_n) | (~grp_process_crc_fu_122.process_blocks_U0.grp_process_blocks_Pipeline_block_loop_fu_199.inByte9_blk_n) | (~grp_process_crc_fu_122.process_blocks_U0.grp_process_blocks_Pipeline_block_loop_fu_199.inByte10_blk_n) | (~grp_process_crc_fu_122.process_blocks_U0.grp_process_blocks_Pipeline_block_loop_fu_199.inByte11_blk_n) | (~grp_process_crc_fu_122.process_blocks_U0.grp_process_blocks_Pipeline_block_loop_fu_199.inByte12_blk_n) | (~grp_process_crc_fu_122.process_blocks_U0.grp_process_blocks_Pipeline_block_loop_fu_199.inByte13_blk_n) | (~grp_process_crc_fu_122.process_blocks_U0.grp_process_blocks_Pipeline_block_loop_fu_199.inByte14_blk_n) | (~grp_process_crc_fu_122.process_blocks_U0.grp_process_blocks_Pipeline_block_loop_fu_199.inByte15_blk_n) | (~grp_process_crc_fu_122.process_blocks_U0.numChunks_blk_n) | (~grp_process_crc_fu_122.process_blocks_U0.chunkSize_blk_n);
    assign proc_3_data_PIPO_blk[1] = 1'b0;
    assign proc_3_start_FIFO_blk[1] = 1'b0;
    assign proc_3_TLF_FIFO_blk[1] = 1'b0;
    assign proc_3_input_sync_blk[1] = 1'b0;
    assign proc_3_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_3[1] = dl_detect_out ? proc_dep_vld_vec_3_reg[1] : (proc_3_data_FIFO_blk[1] | proc_3_data_PIPO_blk[1] | proc_3_start_FIFO_blk[1] | proc_3_TLF_FIFO_blk[1] | proc_3_input_sync_blk[1] | proc_3_output_sync_blk[1]);
    assign proc_3_data_FIFO_blk[2] = 1'b0 | (~grp_process_crc_fu_122.process_blocks_U0.crc_size_blk_n) | (~grp_process_crc_fu_122.process_blocks_U0.init_value_blk_n);
    assign proc_3_data_PIPO_blk[2] = 1'b0;
    assign proc_3_start_FIFO_blk[2] = 1'b0;
    assign proc_3_TLF_FIFO_blk[2] = 1'b0;
    assign proc_3_input_sync_blk[2] = 1'b0;
    assign proc_3_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_3[2] = dl_detect_out ? proc_dep_vld_vec_3_reg[2] : (proc_3_data_FIFO_blk[2] | proc_3_data_PIPO_blk[2] | proc_3_start_FIFO_blk[2] | proc_3_TLF_FIFO_blk[2] | proc_3_input_sync_blk[2] | proc_3_output_sync_blk[2]);
    assign proc_3_data_FIFO_blk[3] = 1'b0 | (~grp_process_crc_fu_122.process_blocks_U0.outStream_blk_n) | (~grp_process_crc_fu_122.process_blocks_U0.numChunks_c_blk_n);
    assign proc_3_data_PIPO_blk[3] = 1'b0;
    assign proc_3_start_FIFO_blk[3] = 1'b0;
    assign proc_3_TLF_FIFO_blk[3] = 1'b0;
    assign proc_3_input_sync_blk[3] = 1'b0;
    assign proc_3_output_sync_blk[3] = 1'b0;
    assign proc_dep_vld_vec_3[3] = dl_detect_out ? proc_dep_vld_vec_3_reg[3] : (proc_3_data_FIFO_blk[3] | proc_3_data_PIPO_blk[3] | proc_3_start_FIFO_blk[3] | proc_3_TLF_FIFO_blk[3] | proc_3_input_sync_blk[3] | proc_3_output_sync_blk[3]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_3_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_3_reg <= proc_dep_vld_vec_3;
        end
    end
    assign in_chan_dep_vld_vec_3[0] = dep_chan_vld_0_3;
    assign in_chan_dep_data_vec_3[4 : 0] = dep_chan_data_0_3;
    assign token_in_vec_3[0] = token_0_3;
    assign in_chan_dep_vld_vec_3[1] = dep_chan_vld_1_3;
    assign in_chan_dep_data_vec_3[9 : 5] = dep_chan_data_1_3;
    assign token_in_vec_3[1] = token_1_3;
    assign in_chan_dep_vld_vec_3[2] = dep_chan_vld_2_3;
    assign in_chan_dep_data_vec_3[14 : 10] = dep_chan_data_2_3;
    assign token_in_vec_3[2] = token_2_3;
    assign in_chan_dep_vld_vec_3[3] = dep_chan_vld_4_3;
    assign in_chan_dep_data_vec_3[19 : 15] = dep_chan_data_4_3;
    assign token_in_vec_3[3] = token_4_3;
    assign dep_chan_vld_3_1 = out_chan_dep_vld_vec_3[0];
    assign dep_chan_data_3_1 = out_chan_dep_data_3;
    assign token_3_1 = token_out_vec_3[0];
    assign dep_chan_vld_3_2 = out_chan_dep_vld_vec_3[1];
    assign dep_chan_data_3_2 = out_chan_dep_data_3;
    assign token_3_2 = token_out_vec_3[1];
    assign dep_chan_vld_3_0 = out_chan_dep_vld_vec_3[2];
    assign dep_chan_data_3_0 = out_chan_dep_data_3;
    assign token_3_0 = token_out_vec_3[2];
    assign dep_chan_vld_3_4 = out_chan_dep_vld_vec_3[3];
    assign dep_chan_data_3_4 = out_chan_dep_data_3;
    assign token_3_4 = token_out_vec_3[3];

    // Process: grp_process_crc_fu_122.write_output_U0
    calculate_crc_hls_deadlock_detect_unit #(5, 4, 2, 2) calculate_crc_hls_deadlock_detect_unit_4 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_4),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_4),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_4),
        .token_in_vec(token_in_vec_4),
        .dl_detect_in(dl_detect_out),
        .origin(origin[4]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_4),
        .out_chan_dep_data(out_chan_dep_data_4),
        .token_out_vec(token_out_vec_4),
        .dl_detect_out(dl_in_vec[4]));

    assign proc_4_data_FIFO_blk[0] = 1'b0 | (~grp_process_crc_fu_122.write_output_U0.grp_write_output_Pipeline_VITIS_LOOP_442_1_fu_58.outStream_blk_n) | (~grp_process_crc_fu_122.write_output_U0.numChunks_blk_n);
    assign proc_4_data_PIPO_blk[0] = 1'b0;
    assign proc_4_start_FIFO_blk[0] = 1'b0;
    assign proc_4_TLF_FIFO_blk[0] = 1'b0;
    assign proc_4_input_sync_blk[0] = 1'b0;
    assign proc_4_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_4[0] = dl_detect_out ? proc_dep_vld_vec_4_reg[0] : (proc_4_data_FIFO_blk[0] | proc_4_data_PIPO_blk[0] | proc_4_start_FIFO_blk[0] | proc_4_TLF_FIFO_blk[0] | proc_4_input_sync_blk[0] | proc_4_output_sync_blk[0]);
    assign proc_4_data_FIFO_blk[1] = 1'b0 | (~grp_process_crc_fu_122.write_output_U0.crc_out_blk_n);
    assign proc_4_data_PIPO_blk[1] = 1'b0;
    assign proc_4_start_FIFO_blk[1] = 1'b0 | (~grp_process_crc_fu_122.start_for_write_output_U0_U.if_empty_n & grp_process_crc_fu_122.write_output_U0.ap_idle & ~grp_process_crc_fu_122.start_for_write_output_U0_U.if_write);
    assign proc_4_TLF_FIFO_blk[1] = 1'b0;
    assign proc_4_input_sync_blk[1] = 1'b0;
    assign proc_4_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_4[1] = dl_detect_out ? proc_dep_vld_vec_4_reg[1] : (proc_4_data_FIFO_blk[1] | proc_4_data_PIPO_blk[1] | proc_4_start_FIFO_blk[1] | proc_4_TLF_FIFO_blk[1] | proc_4_input_sync_blk[1] | proc_4_output_sync_blk[1]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_4_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_4_reg <= proc_dep_vld_vec_4;
        end
    end
    assign in_chan_dep_vld_vec_4[0] = dep_chan_vld_0_4;
    assign in_chan_dep_data_vec_4[4 : 0] = dep_chan_data_0_4;
    assign token_in_vec_4[0] = token_0_4;
    assign in_chan_dep_vld_vec_4[1] = dep_chan_vld_3_4;
    assign in_chan_dep_data_vec_4[9 : 5] = dep_chan_data_3_4;
    assign token_in_vec_4[1] = token_3_4;
    assign dep_chan_vld_4_3 = out_chan_dep_vld_vec_4[0];
    assign dep_chan_data_4_3 = out_chan_dep_data_4;
    assign token_4_3 = token_out_vec_4[0];
    assign dep_chan_vld_4_0 = out_chan_dep_vld_vec_4[1];
    assign dep_chan_data_4_0 = out_chan_dep_data_4;
    assign token_4_0 = token_out_vec_4[1];


`include "calculate_crc_hls_deadlock_report_unit.vh"
